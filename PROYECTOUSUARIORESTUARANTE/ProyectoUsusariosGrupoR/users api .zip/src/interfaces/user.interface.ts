export interface UserI {
  email: string;
  password: string;
  permissionCodes: string[];
}
