export class RegisterDTO {
  email: string;
  password: string;
}
