import { UserEntity } from './user.entity';

export const entities = [UserEntity];
